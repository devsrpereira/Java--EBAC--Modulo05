public class App {
    public static void main(String[] args) throws Exception {
        System.out.println("Ola Mundo Java, Estou Chegando!!");
    }
}
